<?php

     mysql_connect('localhost','root','') or die('error');
      mysql_select_db('stage') or die('base de données introuvable');
      mysql_query('SET NAMES utf8');

?>